# Handoff: Post detail (assistant) — updated 30 Jul 2026

## Overview
The assistant's **post detail** screen: where a post that came back with change requests gets fixed
and resubmitted. Two views in one file — desktop full page (1440 × 900, no scroll) and the mobile
sheet (390 × 844). This bundle covers **only** this screen; the rest of the reorganisation is in
`design_handoff_bloom_dashboards`.

## About the design files
`Post detail -updated-.dc.html` is a **design reference written in HTML** — a prototype showing
intended look and behaviour, not production code to lift. Recreate it in the Bloom Studio codebase
(`bloom-studio`: Next.js App Router, Tailwind v4, Supabase) using existing components and tokens.
Open the file directly in a browser; `support.js` sits beside it and must stay in the same folder.

Data in the mock is illustrative but internally consistent (Lumiere Skin Studio, "Meet the Glow
Renewal facial", Reel, due 13 Jul, goes out 15 Jul, v1, Akeel requested changes 13 Jul).

## Fidelity
**High-fidelity.** Colours, type, spacing and states are final; match them.

## What changed in this pass
1. **On-creative copy field removed** — the field no longer exists on this screen.
2. **Caption is real content** with a `238 / 2,200` counter, a `Copy` link, and the hashtag run in
   `#2b7c8f`.
3. **Internal notes are filled**, labelled "not shown to the client", and carry a link to the grade
   reference (`warm_lut_v3`).
4. **Creative is a real 9:16 preview** (play button, `9:16 · 1080×1920`, `0:24`, filename + size,
   download / open-external) instead of an empty drop zone; the drop zone is now the *awaiting* state.
5. **Source media is specific:** "6 clips from the 9 Jul shoot", `Open in library`, four clip chips with
   durations on dark pills (`0:12`, `0:08`, `0:19`, `+3`).
6. **Activity gained two system entries:** `Mia uploaded v1 · 12 Jul, 4:20pm` and
   `Scheduled for 15 Jul from the July plan · 4 Jul`.
7. Mobile sheet brought in line with all of the above.

## Layout — desktop (1440 × 900)
- Sidebar 224px (`linear-gradient(180deg,#37727c,#3a5f77)`), header 64px, main padding `20px 28px 24px`,
  content column `max-width:1152px`, vertical `gap:14px`, no page scroll.
- Body grid: `1fr 372px`, `gap:16px`. Left = fields card; right = creative card over activity card.
- Cards: `radius 24px`, `1px solid #e3f0ef`, `#fbfdfd`, shadow
  `0 1px 2px rgba(20,58,67,.05), 0 10px 28px rgba(20,58,67,.08)`.
- Inputs/selects: 36px, `radius 12px`, `1px solid #b3d6d5`, `#fbfdfd`, 13px `#143a43`.
- Field labels 11.5px/500 `#47686f`; hints 11px `#86a6ab`.

### Header row
48px type tile, `radius 14px`, `linear-gradient(135deg,#D5ECEC,#D8C489,#164A56)`, label "Reel" 12px/500
`#164a56`. Title Fraunces 23px/400 `-.01em` `#143a43`. Stage pill "Changes requested":
`background:color-mix(in srgb,#e28a84 16%,white)`, text `#e28a84`, 6px dot, `radius 999px`, `3px 10px`.
Subline 12.5px `#86a6ab`: "Lumiere Skin Studio · v1 · goes out 15 Jul · all changes saved".
Actions right: ghost `Upload new version` (36px, `1px solid #e3f0ef`, `#fbfdfd`, 12.5px `#47686f`);
primary `Submit for review` (36px, `#45a7ba`, white 13px/500, `send` icon).

### Change-request band
`radius 20px`, border `color-mix(in srgb,#e28a84 34%,white)`, fill `color-mix(in srgb,#e28a84 7%,white)`,
padding `14px 16px`. Left: 28px avatar `A` on `#b7e1e6`, "Akeel asked for changes" 13px/500 `#143a43`,
"13 Jul · 14 days ago" 11.5px `#86a6ab`, note 13px/1.55 `#47686f`. Right (min 190px): the note parsed
into a checklist — done item has a `#3f9a7f` 16px check box and strike-through text; open item a
`1.5px solid #e28a84` box; footer "1 of 2 notes done" 11px `#86a6ab`.

### Fields card (left), top to bottom
1. 4-up grid `repeat(4,1fr)`, `gap:10px`: **Post type** (Reel) · **Goes out** (15 Jul) · **Due** (13 Jul,
   late → border `color-mix(in srgb,#e28a84 45%,white)` and text `#e28a84`) · **Owner** (Mia Rivera).
2. **Pillars** — hint "colour the post on the calendar". Selected chip: `1px solid #D8C489`,
   `color-mix(in srgb,#D8C489 16%,white)`, text `#a8842f`. Unselected: `1px solid #b3d6d5`, `#47686f`.
   Chips: Behind the scenes (selected) · Educational · Trust building · Beauty & results.
3. **Concept** — read/edit block, `radius 14px`, `1px solid #e3f0ef`, `#f6fbfa`, 13px/1.6 `#47686f`:
   "Teaser of the treatment room, hands, warm light. End on launch date card."
4. **Caption** — hint "plain text, pastes cleanly into Instagram", right-aligned `238 / 2,200` counter
   and `Copy` link. Body as in the mock; hashtags as a separate line in `#2b7c8f`.
5. Footer row (`border-top:1px solid #e3f0ef`, `padding-top:12px`): **Colour scheme** — three 30px
   swatches `radius 9px` (`#D5ECEC`, `#D8C489`, `#164A56`) plus a dashed add tile — and **Internal
   notes**, filled, hint "not shown to the client".

### Creative card (right rail, top)
Header: "Finished creative" 11.5px/500, `v1` chip on `#e0eeee`, `Version history` link.
Preview: `height 158px`, `radius 16px`, `overflow:hidden`; the video frame is represented by
`linear-gradient(135deg,#D5ECEC,#D8C489 55%,#164A56)` — replace with the real poster frame.
- Centred play button: 44px circle, `rgba(251,253,253,.92)`, icon `#164a56`.
- Badges on `rgba(20,58,67,.55)` pills, 10.5px `#fbfdfd`: `9:16 · 1080×1920` top-left, `0:24` top-right.
- Bottom scrim `linear-gradient(180deg,rgba(20,58,67,0),rgba(20,58,67,.55))` with
  `glow_renewal_teaser_v1.mp4 · 42 MB` and two 26px round buttons (download, open external).

Source media row: "Source media" 11.5px/500, "6 clips from the 9 Jul shoot" 11px `#86a6ab`,
`Open in library` link. Then four 38px chips, `radius 9px`, `gap:6px`: three gradient thumbnails whose
durations sit on `rgba(20,58,67,.6)` pills (`0:12`, `0:08`, `0:19`) and a dashed `+3` tile.
**Do not** put duration text directly on the light gradients — it fails contrast.

### Activity card (right rail, bottom, fills remaining height)
Fraunces 17px "Activity" + a `Studio | Client` segmented toggle (28px, active `#d5ecec` / `#164a56`).
Entries, newest first: Akeel + `Changes` pill (13 Jul) → Mia's first-cut comment (12 Jul) →
`Mia uploaded v1 · 12 Jul, 4:20pm` → `Scheduled for 15 Jul from the July plan · 4 Jul`. System entries
use a 26px `#e0eeee` circle with a `#2b7c8f` icon and 12px `#86a6ab` text. Base (pinned,
`border-top:1px solid #e3f0ef`): input "Leave a comment for Akeel" (36px pill, `1px solid #b3d6d5`) plus
a 36px `#45a7ba` send button.

## Layout — mobile (390 × 844)
Sheet over a dimmed production list (`rgba(20,58,67,.28)` scrim), height 88%, `radius 26px 26px 0 0`,
`box-shadow:0 -20px 50px rgba(20,58,67,.22)`, 4×44px grab handle.
Header: 38px type tile, title 14px/500 truncated, "v1 · all changes saved", 44px close button.
Scroll body (`padding:14px 16px`): change-request card with checklist → 2×2 field grid (Stage · Owner ·
Due · Goes out, 44px controls) → creative preview `height 170px` (same treatment, badges `9:16` and
`0:24`, filename scrim) → Concept → Caption with counter + `Copy` → Internal notes.
Footer bar (`#f6fbfa`, `border-top`): 48px primary `Submit for review` + 48px comment button.
All tap targets ≥ 44px.

## Interactions & behaviour
- Fields edit in place and autosave — the header reads "all changes saved" (debounce ~600ms, then
  update the timestamp; on failure show a retry chip rather than a modal).
- Change-request checklist items toggle locally and drive the "1 of 2 notes done" count; state must
  persist per feedback note (see State).
- `Copy` copies the caption as plain text including hashtags; show a transient "Copied" confirmation.
- `Upload new version` opens the file picker; on upload the version chip increments, an activity entry
  is appended, and the stage moves to *In review* on `Submit for review`.
- `Submit for review` is disabled while any checklist item is open only if the studio wants that guard —
  the mock leaves it enabled and relies on the count as a nudge.
- Play button opens the video (lightbox on desktop, native player on mobile). Download and
  open-external act on the stored asset URL.
- Activity toggle filters the thread to studio-only or client-visible entries; comment posts optimistically.
- Hover: cards unchanged; links `#2b7c8f` → darken; buttons lighten ~4%. Focus rings 3px at 35% of the
  accent. Transitions 120–160ms `ease-out`.

## State
- `post` (type, goesOutAt, dueAt, ownerId, pillars[], concept, caption, colourScheme[], internalNotes)
- `versions[]` with `current` (filename, size, duration, aspect, posterUrl) → drives preview vs awaiting
- `sourceClips[]` (thumbnail, duration) with a `+N` overflow count and shoot date
- `feedbackChecklist` — parse the latest `changes_requested` note into lines; if parsing proves fragile,
  store checklist items alongside the feedback record
- `activity[]` (comments + system events, each flagged studio / client visible)
- `saveState`: `idle | saving | saved | error`

## Tweaks in the prototype
The file exposes three props (Tweaks panel, section "Post detail") so states can be reviewed without
new data: `creativeUploaded` (preview ↔ awaiting drop zone), `showInternalNotes` (client-safe view),
`showHashtags`.

## Design tokens
Ink `#143a43` · body `#47686f` · muted `#86a6ab` · line `#e3f0ef` · line-strong `#b3d6d5` ·
surface `#fbfdfd` · surface-2 `#f6fbfa` · tint `#e0eeee` / `#d5ecec` · accent `#45a7ba` ·
accent-deep `#2b7c8f` · plum `#164a56` · gold `#D8C489` (text `#a8842f`) · coral `#e28a84` ·
green `#3f9a7f` · avatar `#b7e1e6`.
Radii: 999px pills · 12px inputs · 14px blocks · 16px media · 20–24px cards · 26px sheet · 34px phone.
Type: Fraunces 400 for headings (23px page title, 17px card title); UI sans 10.5–14px, 500 for labels
and buttons; line-height 1.5–1.6 for prose.
Spacing: 6 · 8 · 10 · 12 · 14 · 16 · 18 · 20 · 24 · 28.
Shadows: card `0 1px 2px rgba(20,58,67,.05), 0 10px 28px rgba(20,58,67,.08)`;
frame `0 30px 70px rgba(20,58,67,.18)`; sheet `0 -20px 50px rgba(20,58,67,.22)`.

## Assets
Icons: Lucide (`arrow-left`, `bell`, `upload-cloud`, `send`, `play`, `download`, `external-link`,
`calendar`, `chevron-down`, `check`, `plus`). Gradients stand in for the video poster, clip thumbnails
and colour swatches — no bitmap assets ship in this bundle.

## Files
| File | Contents |
|---|---|
| `Post detail -updated-.dc.html` | Desktop full page + mobile sheet (open in a browser) |
| `support.js` | Runtime the HTML reference needs — keep alongside |
| `README.md` | This spec |

Codebase touchpoints: `src/app/(app)/production/page.tsx`,
`src/components/production-workspace.tsx`, `src/components/comment-thread.tsx`,
`src/components/asset-viewer.tsx`, `src/lib/{data,actions}.ts`.
