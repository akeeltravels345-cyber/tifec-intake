# Handoff: Intake — Billing Style Harmonization

## Overview
The billing feature (owner "Business overview" + related screens) was recently added to the
existing **TIFEC Client Intake** app and shipped with a deliberate **editorial** visual language:
warm/light paper background, **Newsreader** serif for headings & numbers, indigo + teal accents,
amber for "attention" states. The intake side of the app still used the older `dm-*` "modern
dashboard" look (cool `#f3f6f7` background, Open Sans + Carlito, teal-forward, no serif), so the
two halves read as two different products.

This handoff **restyles the intake dashboard to match the billing redesign's family**, while
keeping a small, intentional divergence so the intake side still feels like the *intake* side
(teal-forward accents, "TIFEC Intake / Client Intake" brand block). No intake functionality
changes — only presentation.

The design reference is `Intake Dashboard.dc.html`, which recreates the app's
`components/DashboardShell.tsx` (the clinician/owner submissions dashboard + the Forms view) in
the new style.

## About the Design Files
The files in this bundle are **design references authored in HTML** (a component format called
"DC" — a thin runtime wrapper around React). They are prototypes showing intended look and
behavior — **not production code to copy directly**.

Your task is to **recreate this styling in the target codebase's existing environment**. The app
is **Next.js + React (TypeScript)** (worktree `tifec-billing`: App Router, client components under
`components/*`, global CSS in `app/globals.css`). The intake dashboard already exists as
`components/DashboardShell.tsx` driven by the `dm-*` class block at the bottom of
`app/globals.css`. **This is a styling pass:** keep the component's structure, state, props, and
data flow; re-skin the `dm-*` rule block (and the shared tokens) to the values below. Treat the
`class Component extends DCLogic` block in the `.dc.html` as reference for derived values only —
the real logic already lives in `DashboardShell.tsx`.

## Fidelity
**High-fidelity.** Final colors, typography, radii, spacing, and interactions are specified below
and are exact. Match them. Where a value harmonizes with an existing billing token, the billing
token is the source of truth (see `design_handoff_billing_redesign/README.md` in the same repo).

## Design Tokens

These extend/replace the intake portion of `:root` in `app/globals.css`. The billing screens
already use the same indigo/teal/amber; reuse those variables rather than introducing new ones.

**Colors**
- Indigo (primary / links / "Total" / brand): `#2E3192`
- Teal (accents / active nav / "Reviewed" / avatars): `#2F8E93`  · deep `#256E72`
- Ink (text): `#22283A`  · muted `#6B7580`  · faint `#9AA0A6`
- **Background base (chosen: "1d — crisp white + tint")**: `#F8F9F8`
- Card surface: `#FFFFFF`
- Card edge / hairline: edge `#E6E7E2`, hair `#EDEEE9`
- Amber ("New" / attention): text `#BE8127`, bg `#F6ECD9`, line `#ECD9B8`, dot `#D9A441`
- Green ("Reviewed" pill): text `#147a45`, bg `#E3F4EA`
- Archived pill: text `#8b8674`, bg `#EEE9DD`, dot `#c8bfab`
- Nav "active" wash: `#eef4f3` (text `#256E72`); nav hover wash `#f3f0e8`

**Background treatment** (the app-shell background, behind sidebar + main):
```css
background:
  radial-gradient(1100px 460px at 92% -12%, rgba(47,142,147,.13), transparent 58%),
  #F8F9F8;
background-attachment: fixed;
```
Plus a fixed 3px brand strip across the very top of the shell:
```css
background: linear-gradient(90deg, #2F8E93 0%, #2E3192 55%, #E7C350 100%);
/* position:fixed; top:0; left:0; right:0; height:3px; z-index:50 */
```
> Background history: we evaluated warm cream (`#FBF9F4`, exact billing match), a cool linen
> (`#EEF2F3`), a diagonal cream→cool gradient, and this near-white "1d". **1d was chosen.**
> `Background Options.dc.html` in this bundle shows all four side by side if you need to revisit.

**Typography**
- Display / headings / numbers: **Newsreader** (serif), weights 400–600. Big figures use
  `font-variant-numeric: tabular-nums`. (Already loaded for billing.)
- Body / labels / UI / buttons: **Open Sans**, 400–800.
- Eyebrow / stat labels: 11px, `letter-spacing:.14em`, uppercase, weight 700, color faint.
- Load via Google Fonts:
  `Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600` + `Open+Sans:wght@400;500;600;700;800`.

**Shape / spacing / shadow**
- Card radius 16px; rows 14px; buttons/inputs 9–11px; pills & dots `border-radius:999px` (dots 3px).
- Card shadow: `0 1px 2px rgba(70,55,25,.03), 0 12px 30px rgba(70,55,25,.05)`.
- Row hover: `0 8px 22px rgba(70,55,25,.07)` + `translateY(-1px)` + border → `#dcd3c0`.
- Sidebar width 242px. Main content `max-width:1180px`, padding `30px 40px 56px`.
- Topbar has a `1.5px solid #2E3192` bottom border, `padding-bottom:20px`, `margin-bottom:26px`.

## Screens / Views

### Sidebar (shared by both views)
- **Layout**: fixed 242px column, white, `border-right:1px solid var(--edge)`, `padding:24px 16px`,
  `position:sticky; top:0; height:100vh`, flex column.
- **Brand block**: 36×36 rounded (10px) logo tile (`assets/tifec-icon.png`, 1px edge border, 3px
  pad) + "TIFEC Intake" (700/15px) over "Client Intake" (11px faint). This label is the
  intentional divergence from billing's "TIFEC Billing / Essential Care".
- **Section label** "PRACTICE": 10.5px, `letter-spacing:.14em`, uppercase, `#b3aa98`, weight 700.
- **Nav items**: flex row, `gap:12px`, `padding:11px 13px`, radius 10px, 14px/600, color `#6a6f66`.
  Feather-style 18px stroke icons (`stroke:currentColor`, `stroke-width:2`).
  - Hover → bg `#f3f0e8`.
  - Active (`.on`) → bg `#eef4f3`, color `#256E72`, weight 700.
  - **Dashboard**: home icon; amber count badge (bg `#BE8127`, white, 11px/700, radius 999px,
    `padding:1px 8px`) when there are submissions needing review.
  - **Forms**: file icon.
  - **Billing**: credit-card icon, links to the billing overview (`/billing` in the app; the mock
    links to `Business Overview.dc.html`). Trailing "OWNER" chip in the amber pill style
    (`.beta`: 9.5px/800 uppercase, amber text on `#F6ECD9`, `#ECD9B8` border).
  - **Admin**: star icon.
- **Spacer** pushes the user card to the bottom.
- **User card**: `border-top:1px solid var(--edge)`, `padding-top:16px`; 34px round avatar with
  `linear-gradient(135deg,#2F8E93,#2E3192)`, white **Newsreader** initials; name 13px/600
  ("Dr. Shion O'Connor"), role 11px faint ("Owner"). Signed in as the same owner as billing so
  navigating between the two feels continuous (shared "SO" avatar).

### View 1 — Dashboard (submissions)
Purpose: owner/clinician triages completed intake submissions.
- **Topbar**: left = greeting `Good {morning|afternoon|evening}, {firstName}` in Newsreader
  500/27px + subline `{long date} · {N submissions waiting for review}` (the count is a
  teal-deep underlined button that filters to New; when zero it reads "you're all caught up").
  Right = search box (white, 1px edge, radius 11px, 280px, magnifier icon + borderless input,
  placeholder "Search submissions…") and a 42px rounded-square (12px) gradient avatar with
  Newsreader initials.
- **Stat cards** (4-up grid, `gap:14px`): clickable filters. Each = white card, 16px radius, card
  shadow, `padding:16px 18px`. Contents: eyebrow label with a 9px square color dot + name;
  Newsreader 400/34px tabular number; faint 11.5px trend caption.
  - New — dot `#D9A441`, "to review"; Reviewed — dot teal, "done"; Archived — dot `#c8bfab`,
    "filed"; Total — dot indigo, "all time".
  - Active filter → border becomes `1.5px` in that stat's color (new=amber, reviewed=teal,
    archived=`#c8bfab`, all=indigo). Hover → `translateY(-2px)` + deeper shadow.
- **Toolbar**: segmented tabs (All / New / Reviewed / Archived) — pill group on `#F0EDE3`, 10px
  radius, 4px pad; active tab white with `0 1px 2px rgba(0,0,0,.06)`, ink text; inactive muted.
  Right: "Showing **N** submission(s)" with a teal-deep underlined "Show all" when filtered.
- **Submission rows** (`gap:10px` list). Each row = white card, grid
  `44px minmax(0,1fr) 190px 108px 74px`, `column-gap:18px`, `padding:15px 18px`, 14px radius.
  - Col 1: 44px avatar tile (12px radius) bg `#eef4f3`, teal-deep Newsreader initials.
  - Col 2: name (700/15px) with inline tags — **Couple** (teal wash), **Linked** (indigo wash
    `#eceef7`/`#2E3192`), **Note** (amber wash); each tag 10.5px/700, `padding:2px 8px`, radius
    999px. Below: email (12.5px faint, ellipsis; "No email provided" when blank).
  - Col 3: form label (13px/700 indigo, ellipsis) over relative time (11.5px faint).
  - Col 4: status pill (11.5px/700, `padding:4px 12px`, radius 999px) — New amber, Reviewed green,
    Archived neutral.
  - Col 5: "Open ›" (12.5px/700 teal-deep, chevron icon), right-aligned.
  - Hover: see shadow token above.
- **Empty state**: dashed-edge white card, Newsreader 500/19px title "No matching submissions" +
  faint hint ("Try a different search or filter." / "Completed forms will appear here.").

### View 2 — Forms
Purpose: clinician copies the right client link / previews a form.
- **Topbar**: "Intake forms" (Newsreader) + subline "Share the right link with each client.
  Completed forms appear under Dashboard." Right: a rounded pill note (shield icon +
  "Consent included in every form", teal-deep) and the avatar.
- **Form cards** (2-up grid, `gap:14px`): white, 16px radius, card shadow, `padding:22px`, flex
  column. Header = 48px rounded (13px) gradient icon tile (file glyph) + name (700/16px) over
  "Client sees: “…”" (12px faint). Description 13px muted, `line-height:1.55`. Meta chips
  (teal wash, 11px/600, radius 999px). Actions: primary "Copy client link" (indigo fill, white)
  + ghost "Preview" (white, edge border, teal-deep on hover). Both 12.5px/600, radius 9px.
  - Icon tile gradients: intake=teal (`#2F8E93→#256E72`), couples=indigo (`#6d71c9→#2E3192`),
    screenings=amber (`#D9A441→#BE8127`).
  - Four forms: **Individual Intake** (client: "Intake Form"), **Couples Intake**
    (client: "Couples Intake Form"), **Wellbeing Screening (Adult)** (client: "Wellbeing
    Screening"), **Child Wellbeing Screening**. Copy is in the DC; real labels come from
    `lib/forms.ts` (`label` / `clientLabel`).
- **Consent note** below the grid: faint 12.5px on `#faf7f0`, 1px hair border, 11px radius —
  explains consent + Data Protection (2021) is appended to intake/couples; screenings skip it.

## Interactions & Behavior
- **Nav Dashboard ⇄ Forms**: toggles the main view (client-side `view` state). Billing/Admin are
  real links/navigation.
- **Stat card click**: sets the status filter (`new|reviewed|archived|all`); active card gets the
  colored border; list + result count update.
- **Segmented tabs**: same status filter as the stat cards (kept in sync).
- **Search**: case-insensitive substring match across client name, email, and form label; updates
  the list + count live.
- **Review link** in the subline and "Show all" both just set the status filter.
- Transitions: card/row hover `transform` + `box-shadow` ~`.14–.16s`. Respect
  `prefers-reduced-motion` (the app already disables animations/transitions under it).
- **Responsive** (`max-width:900px`): sidebar hidden; main padding `22px 18px 48px`; stat grid
  → 2-up; forms grid → 1-up; search full width; rows collapse to
  `40px minmax(0,1fr) 84px` (form column + "Open" hidden).

## State Management
Existing `DashboardShell.tsx` already owns this — do not rebuild it, just confirm it matches:
- `view: "dashboard" | "forms"`
- `status: "all" | "new" | "reviewed" | "archived"` (defaults to "new")
- `query: string`
- Derived: per-status counts, `needReview` (= new count → sidebar badge + subline), filtered +
  date-sorted rows, relative-time labels.
- Data comes from the submissions API/data layer (`data/submissions.local.json` shape:
  `{token, clinician_id, form_key, status, created_at, couple_id, notes_encrypted, ...}`);
  answers are end-to-end encrypted, so the dashboard shows metadata only. The mock's sample names
  are illustrative — wire to live data.

## Assets
- `assets/tifec-icon.png` — TIFEC mark, sidebar logo tile. Use the real brand asset already in the
  app (`public/tifec-mark.png`) rather than this copy.
- All icons are inline feather-style stroke SVGs (`stroke:currentColor`); no icon font needed.
- No other images; stat dots, pills, and tracks are pure CSS.

## Files (in this bundle)
- `Intake Dashboard.dc.html` — the harmonized dashboard (both views) + its logic reference.
- `Background Options.dc.html` — the four background directions explored; **1d chosen**.
- `assets/tifec-icon.png` — brand mark.
- `support.js` — the DC runtime (only needed to open the `.dc.html` files in a browser).

## Related
- `design_handoff_billing_redesign/` (same repo) — the billing screens whose language this matches.
  Shared tokens (indigo/teal/amber, Newsreader, card shadow, sidebar) should be defined once and
  reused across both.
