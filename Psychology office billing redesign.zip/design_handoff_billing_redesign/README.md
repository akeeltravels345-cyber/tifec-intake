# Handoff: TIFEC Billing System Redesign

## Overview
A calm, trustworthy billing system for **The Institute for Essential Care (TIFEC)**, a psychology practice in Grand Cayman. It replaces the existing owner "Business overview" and its related screens. The redesign is organized around three questions the practice needs answered at a glance:

1. **Money in vs. money owed** — what was *earned* (work delivered) vs. the *cash actually collected*, and what insurers still owe.
2. **A payout you can trust** — every clinician payout traceable to the cent (60% of collected, less deductions).
3. **Who owes you & for how long** — aging insurance claims, oldest first.

There are three user perspectives:
- **Owner** (Dr. Shion O'Connor) — whole-practice money view; sees everything.
- **Clinician** (e.g. Dr. Donnet O'Connor) — only their own payout + logging sessions.
- **Biller** (Nick O'Connor) — the claims queue; earns **3% of insurance collected**.

## About the Design Files
The files in this bundle are **design references authored in HTML** (a component format called "DC" — a small runtime wrapper around React). They are prototypes showing intended look and behavior — **not production code to copy directly**.

Your task is to **recreate these designs in the target codebase's existing environment**. The original app is **Next.js + React (TypeScript)** (see "Source codebase" below), so recreate them as React components using the app's established patterns, routing, and data layer. Each `.dc.html` file contains inline-styled markup plus a `class Component extends DCLogic` block — treat that class as a plain React component (state, handlers, derived values in `renderVals()` map directly to `useState` + render logic).

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions are all specified. Recreate the UI pixel-perfectly using the codebase's libraries and patterns. All monetary figures are real, reconciled July/June 2026 sample data — wire them to live data, don't hardcode.

## Design Tokens

**Colors**
- Indigo (primary / payouts / net): `#2E3192`  · soft `#4B4FA6`
- Teal (collected / positive / accents): `#2F8E93` · deep `#256E72`
- Ink (text): `#22283A`  · muted `#6B7580` · faint `#9AA0A6`
- Paper (app background): `#FBF9F4`  · cool panel `#F3F6F7`
- Card edge / hairlines: `#ECE6DA` (edge), `#F0EADE` (hair)
- Amber (owed / aging warning): text `#BE8127`, bg `#F6ECD9`, track gradient `#D9A441 → #C98A2B`
- Negative / red (deductions, shortfall): `#a5432f`
- Positive green (paid pills, deltas): `#2c7a55` on `#dcefe0`; delta `#147a45` on `#e3f4ea`

**Typography**
- Display / numbers / headings: **Newsreader** (serif) — weights 400–600. Big money figures use `font-variant-numeric: tabular-nums`.
- Body / labels / UI: **Open Sans** — 400–800.
- (Exploration file `Billing Redesign.dc.html` also references **Space Grotesk**; not used in the final screens.)
- Eyebrow labels: 11px, `letter-spacing: .14–.16em`, uppercase, teal-deep or faint, weight 700.

**Spacing / shape**
- Card radius 14–18px; pills/tracks `border-radius: 999px`; buttons 8–11px.
- Card shadow: `0 1px 2px rgba(70,55,25,.03), 0 12px 30px rgba(70,55,25,.05)`.
- Sidebar width 242px. Main content max-width ~1120–1180px, padding 30px 40px.
- Progress/segment bars: 9–16px tall. Bar transitions `width .4–.5s cubic-bezier(.22,1,.36,1)`.

**Money model (business logic — critical)**
- **Earned** = value of all sessions delivered in the month = **Collected of earned** + **Still owed by insurers**.
- **Collected (cash)** this month = co-pays taken at visits + insurance payments received (incl. rollover from earlier months). This is the only basis for payouts.
- **Clinician payout** = 60% of *collected* attributable to that clinician, minus deductions (40% company retention is the complement; some clinicians have a fixed health-insurance deduction, e.g. Dr. Donnet −$250).
- **Biller commission** = 3% of insurance collected; comes out of the practice's retained share, never a clinician's payout.
- **Running expenses** = fixed monthly overhead (marketing $1,300, rent & utilities $900, software & licenses $180 = $2,380/mo).
- **Net this month** = collected − payouts − biller 3% − running expenses (can be negative in a low-collection month).
- **Projected net** = net + (outstanding × ~0.37), i.e. the practice keeps ~37% of insurance once it lands (after 60% payout + 3% biller).

## Screens / Views

### 1. Business Overview (`Business Overview.dc.html`) — Owner
Whole-practice money view. Sidebar (logo, Practice nav: Overview / By clinician / Billing queue [badge 6] / Setup; "View as" role switch; user card) + scrolling main.
- **Top bar**: title "Business overview", subtitle, quick actions (**Log a session** → Log Session, **Export month** → opens summary modal, **Payout statements** → Payout Statement), and a **June ⇄ July 2026** month toggle. Switching month recomputes every figure, bar, and list.
- **Hero (2 cards)**: "Work earned" (big Newsreader figure + delta pill; segmented bar collected vs owed with legend) and "Cash actually collected" (broken into co-pays / insurance received / of-which-rollover). A bridge line explains the difference.
- **Bottom-line card**: waterfall — Cash collected → −Clinician payouts → −Biller commission 3% → −Running expenses → **Net this month** (Newsreader, red if negative). Below it a teal "Projected +/−X once the $Y outstanding lands" chip and an honest plain-language note.
- **Cash trend card**: 6-month collected-cash area+line sparkline (SVG), current month marked with an indigo ring dot.
- **Running expenses card**: rows (name, who/detail, itemized breakdown, monthly amount).
- **Waiting on insurance card**: per-insurer rows — name, claim count, amber progress track, "oldest Nd" age pill (amber if ≥15 days), amount.
- **By clinician**: sort tabs (Collected / Outstanding / Payout). Each row: name + appt count, collected/owed split track with captions, payout (indigo). Click a row to expand: revenue earned / already billed / still outstanding / collected at visit + a billed-progress bar and note.
- **Export month modal**: overlay sheet — KPI grid (earned/collected/outstanding/appointments), the waterfall as a table, two columns (payout by clinician, outstanding by insurer), Print/Save PDF button (print CSS isolates the sheet). Close via backdrop or ✕.

### 2. Clinician Detail (`Clinician Detail.dc.html`) — Clinician (also owner's drill-down)
Per-clinician payout view, locked to the signed-in clinician (no clinician picker, no back-to-overview in the clinician's own view). Sidebar nav is scoped to **My payout** + **Log a session** only.
- Top bar: avatar, name, credentials, month toggle.
- KPIs: Total appointments logged / Total earned / Collected / Outstanding.
- **Payout receipt** (left): Collected this month → −Company retention (40%) → −Health insurance (if any) → **Net payout** (indigo), with a flow bar and a note that payout follows cash actually collected. "View payout statement →" link → Payout Statement.
- **This month's work** (right): billed-vs-coming-in progress + revenue/collected/outstanding/collected-at-visit.
- Sessions table: one row per visit (date, client, code, fee, co-pay, insurance, status badge billed/outstanding/self-pay).

### 3. Billing Queue (`Billing Queue.dc.html`) — Biller
Reconcile insurer remittances. Sidebar scoped to Billing queue only; user = Nick O'Connor "Biller · 3% of collected".
- **Commission hero**: gradient card — your 3% earned this month + what's still waiting; plus KPI cards (outstanding total, claims awaiting, oldest claim in amber).
- **Aging buckets** (0–14 / 15–30 / 31–60 / 60+): click to filter; colored dot + amount + count.
- **Toolbar**: Outstanding / Billed tabs (live counts); search by client; filter by clinician; **By insurer / By clinician** grouping toggle; clear filters.
- **Grouped claims**: each group header has a select-all checkbox, name, count, oldest-age pill, total owed, and "+$X to you" (3%). Rows: checkbox, service date, age pill, client + sub (clinician or insurer depending on grouping), amount, +3%.
- **Batch action bar** (sticky, dark): appears when claims are selected — count + insurance total + your cut, a shared paid-date input, "Mark N billed", clear. Marking moves claims to the Billed tab; **Undo** there reverses. Counts/commission/badge recompute live.

### 4. Setup (`Setup.dc.html`) — Owner
Money rules. Sections:
- **Biller commission**: person card + editable % rate ("of insurance collected").
- **Marketing & admin** (Akeel O'Connor, $1,300/mo) broken into Social media $500 / Web support $500 / Ads $300; plus an **Other fixed monthly costs** table (office rent $750, power & internet $150, EHR & billing $110, Google Workspace $40, bookkeeping $30) totalling **$2,380/mo**, with "+ Add a cost".
- **Insurers & co-pay rules**: editable rows (CINICO none, BritCay 20%, Generali 10%) + add row. Co-pay type: none / fixed $ / % of cost.
- **Service codes**: CPT table (90791 Diagnostic eval, 90834 Therapy 45min, 90837 Therapy 60min, 90847 Family, 90853 Group, 90846).
- **Clinician splits**: retention % + fixed health deduction per clinician.

### 5. Log a Session (`Log Session.dc.html`) — Clinician
Two-column form + live money summary.
- Fields: client name (first/last), date of service, insurance provider (select), **service code chips** (each shows its fee), read-only **Total service cost** and **Duration** (both derived from selected codes — each code carries `fee` and `hrs`), co-pay collected (auto-filled from insurer rule, editable), notes.
- **Live "This session" summary** (sticky): fee, a split bar + lines for **collected at visit** vs **billed to insurance**, and a status note (self-pay → fully collected; insured → "$X enters the billing queue for [insurer]").
- Service-code catalog: 90791 $300/1h, 90834 $200/0.75h, 90837 $250/1h, 90847 $275/0.75h, 90853 $150/1h.

### 6. Payout Statement (`Payout Statement.dc.html`) — printable
A monthly payout statement document (letter-style) with org header/logo, "prepared for" clinician, net payout, KPI grid, the payout calculation table, and an "insurance payments received this month" table. Has a Print/Save PDF action and print CSS. Reached from Clinician Detail.

### 7. Mobile — `Mobile Overview.dc.html` (owner) + `Mobile Screens.dc.html` (clinician / biller / log)
Phone-framed responsive versions of the four money screens. Same numbers, single-column, bottom tab bars, tap targets ≥44px. Biller mobile has tappable claim checkboxes + a sticky mark-billed bar; log mobile keeps the code-driven fee/duration and live split.

## Interactions & Behavior
- **Month toggle** (Overview, Clinician, Mobile): swaps the entire dataset (jul/jun); bars animate width.
- **Clinician row expand** (Overview): toggles a detail panel; chevron rotates 90°.
- **Sort tabs** (Overview by-clinician): re-sorts by collected/owed/payout.
- **Aging bucket filter + grouping toggle + search + clinician filter** (Queue): compose to filter the grouped list.
- **Select claims → batch mark billed → Undo** (Queue): mutates claim `paid`/`paidDate`; recomputes commission, counts, sidebar badge.
- **Service-code selection** (Log): recomputes total, duration, suggested co-pay, and the visit/insurance split live.
- **Export modal / statements / payout statement**: `window.print()` with print stylesheets that isolate the printable sheet; `@page { margin }` set.
- **Follow-up toggle** on aging insurers (Overview earlier variant) marks a claim chased.
- Navigation between screens is via standard links (see each sidebar / back link / quick action).

## State Management
- **Overview**: `{ month, sort, open (expanded clinician id), exportOpen }`. Derived: earned/collected splits, waterfall, projected net, aging, sorted clinicians, export payload.
- **Clinician Detail**: `{ clin, month }` → roster meta + per-clinician per-month data (payout receipt, KPIs, sessions).
- **Billing Queue**: `{ tab, groupBy, q, filterClinician, bucket, selected{}, batchDate, rows[] }`. Claims have `{id,dos,clinician,client,insurer,amount,paid,paidDate}`.
- **Log Session**: `{ first,last,dos,insurerId,codes[],copay,copayTouched,notes }` + CPT and insurer catalogs.
- **Mobile Screens**: `{ cMonth, billed{}, log fields }`.
- Replace all in-file sample arrays with live data from the app's billing API/data layer.

## Assets
- `assets/tifec-icon.png` — TIFEC mark used in every sidebar and the statement header (included in this bundle). Use the real brand asset from the app if available.
- No other images; all charts/bars/donuts are inline SVG or CSS. Icons are inline stroke SVGs (feather-style).

## Source codebase
The original app is a Next.js worktree named **tifec-billing** (see `README.md`/`BILLING-WORKSPACE.md` there): App Router pages under `app/billing/*`, React client components under `components/billing/*`, pure money functions in `lib/billingCalc.ts`, roster in `lib/clinicians.ts`, sample data in `data/billing-*.local.json`, global styles in `app/globals.css`. Recreate these designs against that structure, reusing `billingCalc.ts` as the source of truth for the money math.

## Files (in this bundle)
- `Business Overview.dc.html` — owner overview + export modal
- `Clinician Detail.dc.html` — clinician payout view
- `Billing Queue.dc.html` — biller queue
- `Setup.dc.html` — money rules
- `Log Session.dc.html` — log a session
- `Payout Statement.dc.html` — printable statement
- `Mobile Overview.dc.html`, `Mobile Screens.dc.html` — mobile versions
- `Billing Redesign.dc.html` — the original 3-direction exploration canvas + current-state recreation (reference only)
- `assets/tifec-icon.png`
